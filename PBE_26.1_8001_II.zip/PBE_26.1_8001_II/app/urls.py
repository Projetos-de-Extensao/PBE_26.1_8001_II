from django.urls import path, include
from drf_spectacular.views import SpectacularAPIView, SpectacularSwaggerView
from rest_framework.permissions import AllowAny
from rest_framework.routers import DefaultRouter
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from . import views


router = DefaultRouter()

router.register(r'usuarios', views.UsuarioViewSet)
router.register(r'alunos', views.AlunoViewSet)
router.register(r'professores', views.ProfessorViewSet)
router.register(r'coordenadores', views.CoordenadorViewSet)
router.register(r'empresas', views.EmpresaViewSet)
router.register(r'vagas', views.VagaViewSet)
router.register(r'estagios', views.EstagioViewSet)
router.register(r'documentos', views.DocumentoViewSet)
router.register(r'relatorios', views.RelatorioViewSet)


urlpatterns = [
    path('', views.home, name='home'),
    path('token/', views.token_page, name='token-page'),
    path('api/token/', TokenObtainPairView.as_view(), name='api-token'),
    path('api/token/refresh/', TokenRefreshView.as_view(), name='api-token-refresh'),
    path('api/', include(router.urls)),
    path('api/schema/', SpectacularAPIView.as_view(permission_classes=[AllowAny]), name='schema'),
    path('api/docs/', SpectacularSwaggerView.as_view(url_name='schema', permission_classes=[AllowAny]), name='api-docs'),
]