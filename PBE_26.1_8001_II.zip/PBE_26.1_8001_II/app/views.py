from django.shortcuts import render
from rest_framework import viewsets
from .models import Usuario, Aluno, Professor, Coordenador, Empresa, Vaga, Estagio, Documento, Relatorio
from .serializers import (
    UsuarioSerializer, AlunoSerializer, ProfessorSerializer, CoordenadorSerializer,
    EmpresaSerializer, VagaSerializer, EstagioSerializer, DocumentoSerializer, RelatorioSerializer,
)


def home(request):
    stats = {
        "alunos": Aluno.objects.count(),
        "empresas": Empresa.objects.count(),
        "vagas": Vaga.objects.count(),
        "estagios": Estagio.objects.count(),
        "documentos": Documento.objects.count(),
    }

    api_endpoints = [
        {"path": "/api/usuarios/", "url": "/api/usuarios/", "desc": "Gerenciar usuários"},
        {"path": "/api/alunos/", "url": "/api/alunos/", "desc": "Cadastro de alunos"},
        {"path": "/api/empresas/", "url": "/api/empresas/", "desc": "Empresas parceiras"},
        {"path": "/api/vagas/", "url": "/api/vagas/", "desc": "Vagas de estágio"},
        {"path": "/api/estagios/", "url": "/api/estagios/", "desc": "Estágios ativos"},
        {"path": "/api/documentos/", "url": "/api/documentos/", "desc": "Documentos enviados"},
        {"path": "/api/relatorios/", "url": "/api/relatorios/", "desc": "Relatórios de estágio"},
        {"path": "/api/professores/", "url": "/api/professores/", "desc": "Professores orientadores"},
        {"path": "/api/coordenadores/", "url": "/api/coordenadores/", "desc": "Coordenadores de curso"},
    ]

    return render(request, "home.html", {"stats": stats, "api_endpoints": api_endpoints})


def token_page(request):
    return render(request, "token.html")


class UsuarioViewSet(viewsets.ModelViewSet):
    queryset = Usuario.objects.all()
    serializer_class = UsuarioSerializer


class AlunoViewSet(viewsets.ModelViewSet):
    queryset = Aluno.objects.all()
    serializer_class = AlunoSerializer


class ProfessorViewSet(viewsets.ModelViewSet):
    queryset = Professor.objects.all()
    serializer_class = ProfessorSerializer


class CoordenadorViewSet(viewsets.ModelViewSet):
    queryset = Coordenador.objects.all()
    serializer_class = CoordenadorSerializer


class EmpresaViewSet(viewsets.ModelViewSet):
    queryset = Empresa.objects.all()
    serializer_class = EmpresaSerializer


class VagaViewSet(viewsets.ModelViewSet):
    queryset = Vaga.objects.all()
    serializer_class = VagaSerializer


class EstagioViewSet(viewsets.ModelViewSet):
    queryset = Estagio.objects.all()
    serializer_class = EstagioSerializer


class DocumentoViewSet(viewsets.ModelViewSet):
    queryset = Documento.objects.all()
    serializer_class = DocumentoSerializer


class RelatorioViewSet(viewsets.ModelViewSet):
    queryset = Relatorio.objects.all()
    serializer_class = RelatorioSerializer
