# Sistema de Gestão de Estágios

Bem-vindo ao **IBMEC** — plataforma desenvolvida como projeto de extensão para gerenciar e acompanhar todo o processo de estágios acadêmicos.

!!! info "Sobre o projeto"
    Conectamos **alunos**, **empresas** e **instituição** em um fluxo único e transparente. Do cadastro à conclusão do estágio.

## Navegação

Use as abas acima para explorar as diferentes fases do projeto:

| Fase | Conteúdo |
|------|----------|
| **Iniciação** | Pesquisa, design thinking, brainstorming e prototipagem |
| **Elaboração** | Requisitos, casos de uso e diagramas do sistema |
| **Construção** | Guias de desenvolvimento e ferramentas |
| **Transição** | Informações de transição do projeto |

## Equipe

- Rafael Barbosa
- Jorge Alves
- Davi Ito
- Gabriel Lima
- Gabriel Aguiar

---

Explore cada seção para entender melhor o processo de desenvolvimento deste sistema!
